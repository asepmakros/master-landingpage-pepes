<?php

// $koneksi = new mysqli("localhost", "ciww8346_asep", "makroscovic", "ciww8346_cfgamma");
$koneksi = new mysqli("localhost", "root", "", "cfgamma");

?>